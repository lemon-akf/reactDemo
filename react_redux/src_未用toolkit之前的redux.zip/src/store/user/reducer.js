
const initilState = {
    userInfo: {
        name: 'harry',
        leave: '100'
    }
}

function reducer(state = initilState,action){

    return state
}

export default reducer