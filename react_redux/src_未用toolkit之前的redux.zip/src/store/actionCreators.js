
import * as actionTypes from "./constants"
import axios from "axios"

export const changeActionBanners = (banners)=>({
  type: actionTypes.CHANGE_BANNERS,
  banners
})

export const fetchBannersAction = ()=>{
  // 如果是一个普通的 action 那么我们这里需要返回 action 对象
  // 但是对象中是不能直接拿到从服务器请求的异步数据的

  return function (dispatch,getState){

    axios.get("/banner.json").then(res => { 
      const banners = res.data.banners
      dispatch(changeActionBanners(banners))
    })
  }
}


 