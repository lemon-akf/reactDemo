// import { configureStore } from "@reduxjs/toolkit"

// import counterReducer from "./features/counter"

import { createStore,applyMiddleware,compose,combineReducers} from "redux";
import thunk from "redux-thunk"
import rootReducer from "./reducer";
import homeReducer from "./home/reducer"
import counterReducer from "./counter/reducer"

// const store = configureStore({
//   reducer:{
//     counter:counterReducer
//   }
// })

const reducer = combineReducers({
  root:rootReducer,
  home:homeReducer,
  counter:counterReducer
})

// 用来开启 redux_devtools
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose

// redux-thunk、applyMiddleware解释：
// 因为在 store 的 actioncreators 里默认情况下 dispatch(action) 我们写的 action 需要是 对象类型，
// 但是如果想要在 actioncreators 里做异步网络请求,我们需要返回 函数 类型，需要 redux-thunk 中间件，可以让dispatch(action(函数))。

const store = createStore(reducer,composeEnhancers(applyMiddleware(thunk)))

export default store
