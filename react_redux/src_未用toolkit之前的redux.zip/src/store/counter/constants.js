
export const ADD_NUM = "add_num";
export const SUB_NUM = "sub_num"
