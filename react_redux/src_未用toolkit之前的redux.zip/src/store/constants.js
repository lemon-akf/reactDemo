export const CHANGE_BANNERS = "change_banners";

