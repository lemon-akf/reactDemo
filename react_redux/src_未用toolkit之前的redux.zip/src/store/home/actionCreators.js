// import * as actionTypes from './constants'
import axios from "axios"
import { CHANGE_FURNITURE } from './constants';

export const changeFurnitures = (furnData) => {
    return {
        type: CHANGE_FURNITURE,
        furnData
    }
}

export const fetchFurnituresMultidataAction = () => {

    return (dispatch, getState) => {
        axios.get("/furniture.json").then(res => {
            const furnData = res.data.furniture
            // console.log('furnData', furnData);
            dispatch(changeFurnitures(furnData))
        })
    }
}