import * as actionTypes from './constants'

const initialState = {
  furnData:[],
}

function reducer (state = initialState ,action){
  switch(action.type){
    case actionTypes.CHANGE_FURNITURE:
      return{...state,furnData:action.furnData}
    default:
      return state
  }

}

export default reducer