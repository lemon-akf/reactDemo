
export const CHANGE_FURNITURE = "change_furniture"