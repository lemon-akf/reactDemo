import { CHANGE_BANNERS } from "./constants"

const initialState = {
  name: 'harry',
  banners:[]
}

function reducer(state = initialState, action) {
  switch (action.type) {
    case CHANGE_BANNERS:
      return { ...state, banners: action.banners }
    default:
      return state
  }
}
export default reducer