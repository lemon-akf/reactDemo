import React, { PureComponent } from 'react'

import { addActionNum } from '../store/counter/actionCreators'
import { fetchFurnituresMultidataAction } from '../store/home/actionCreators'
import { connect } from 'react-redux'

export class Home extends PureComponent {

  componentDidMount() {
    this.props.getFurniturs()
  }

  render() {

    const { furnData, counter } = this.props
    return (
      <div>home page
        <h1>当前计数：{counter}</h1>
        <ul>
          {furnData.map((item, index) => {
            return <li key={index}>{item.name}</li>
          })}
        </ul>
        <button onClick={e => this.props.addChangeNum(1)}>+1</button>
        <button onClick={e => this.props.addChangeNum(5)}>+5</button>
        <button onClick={e => this.props.addChangeNum(10)}>+10</button>
      </div>
    )
  }
}


const mapStateToProps = (state) => ({
  furnData: state.home.furnData,
  counter: state.counter.counter
})

const mapDispatchToProps = (dispatch) => ({
  getFurniturs: () => { dispatch(fetchFurnituresMultidataAction()) },

  addChangeNum: (num) => { dispatch(addActionNum(num)) }

})

export default connect(mapStateToProps, mapDispatchToProps)(Home)