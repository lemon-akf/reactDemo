import React, { PureComponent } from 'react'
import { connect } from 'react-redux'

export class Category extends PureComponent {

  componentDidMount() {
    
  }

  render() {
    const { counter, banners } = this.props
    return (
      <div>
        <h1>category</h1>
        <h2>当前计数：{counter}</h2>
        <ul >
          {banners.map((item, index) => {
            return <li key={index}>
              <a href={item.url}>{item.title}</a>
            </li>
          })}
        </ul>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  counter: state.counter.counter,
  banners:state.root.banners
})

const mapDispatchToProps = (dispatch) => ({

})

export default connect(mapStateToProps, mapDispatchToProps)(Category)